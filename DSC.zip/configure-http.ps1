Configuration WebsiteTest {

    # Import the module that contains the resources we're using.
    Import-DscResource -ModuleName PsDesiredStateConfiguration

    # The Node statement specifies which targets this configuration will be applied to.
    Node 'localhost' {

        # The first resource block ensures that the Web-Server (IIS) feature is enabled.
        WindowsFeature WebServer {
            Ensure = "Present"
            Name =  "Web-Server"
        }

        Script DownloadFiles {

                GetScript = { 
                    return @{ 'Result' = $true }
                }
                SetScript = {
		            $url = "https://raw.githubusercontent.com/bwatts64/SQLAA/master/Atlanta-GA.jpg"
                    $wc = New-Object System.Net.WebClient
                    $wc.DownloadFile($url, "C:\inetpub\wwwroot\Atlanta-GA.jpg")
                    (curl https://raw.githubusercontent.com/bwatts64/SQLAA/master/iisstart.htm).content | out-file C:\inetpub\wwwroot\iisstart.htm
                }
                TestScript = {
                    $false
                }

           
        }
    }
} 